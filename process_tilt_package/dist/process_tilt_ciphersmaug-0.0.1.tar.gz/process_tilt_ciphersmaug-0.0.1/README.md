# Building
https://packaging.python.org/en/latest/tutorials/packaging-projects/

```
python -m build